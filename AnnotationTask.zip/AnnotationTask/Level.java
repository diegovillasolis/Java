
public enum Level {
    BAD, INDIFFERENT, GOOD
}
