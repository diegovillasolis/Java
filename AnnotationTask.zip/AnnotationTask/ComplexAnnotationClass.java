
@ComplexAnnotation(
        simpleAnnotation = @SimpleAnnotation(),
        id=1,
        synopsis = "Request for enhancement",
        engineer = "Diego",
        date = "2017-01-01",
        integers = Integer.class,
        value = Level.BAD)
public class ComplexAnnotationClass {

}
